

def get_array():
  import numpy as np
  import os

  
  
  #x = np.array([1, 2, 3, 4])
  x = os.getcwdb()
  
  return(x)


